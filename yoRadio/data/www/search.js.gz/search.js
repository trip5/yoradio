const gateway = `ws://${window.location.hostname}/ws`;
let websocket;
let stationArr = [];
let currentPage = 0; // zero-based
let limit_per_page = 50;
let lastSearchType = 'name';
let lastSearchTerm = '';

// Enable testing mode to bypass server interactions
const testingMode = false;

window.addEventListener('load', onLoad);

function onLoad(event) {
  // Centralized event listeners
  document.getElementById('searchdone').addEventListener('click', () => { window.location.href = '/'; });

  document.querySelectorAll('.quickbutton').forEach(button => {
    button.addEventListener('click', (event) => {
      const genre = event.target.dataset.genre;
      if (genre) {
        quickSearch(genre);
      }
    });
  });

  document.getElementById('prevPageBtn').addEventListener('click', () => changePage(-1));
  document.getElementById('nextPageBtn').addEventListener('click', () => changePage(1));
  document.getElementById('addSearchRowBtn').addEventListener('click', addSearchRow);
  document.getElementById('removeSearchRowBtn2').addEventListener('click', () => removeSearchRow(2));
  document.getElementById('removeSearchRowBtn3').addEventListener('click', () => removeSearchRow(3));
  document.getElementById('searchBtn').addEventListener('click', () => searchStations());

  // Enable/disable search button based on input
  const searchInputs = document.querySelectorAll('#searches input[type="text"]');
  searchInputs.forEach(input => {
    input.addEventListener('input', updateSearchButtonState);
  });

  document.getElementById('stationsTable').addEventListener('click', (event) => {
    const button = event.target.closest('button[data-action]');
    if (button) {
      const index = button.dataset.index;
      const action = button.dataset.action;
      if (action === 'preview') {
        sendStationAction(index, false);
      } else if (action === 'add') {
        sendStationAction(index, true);
      }
    }
  });

  // The HTML file defines the correct initial state (rows 2 and 3 hidden).
  // We just need to handle the logic branch.
  if (testingMode) {
    // In testing mode, we don't load history, so the UI starts as defined in the HTML.
    // We just need to load the mock data.
    loadMockData();
  } else {
    initWebSocket();
    loadLastSearchAndResults(); // This function handles UI reset and then applies history.
  }
  updateSearchButtonState(); // Initial check
}

function updateSearchButtonState() {
  const searchBtn = document.getElementById('searchBtn');
  let hasInput = false;
  document.querySelectorAll('.search-row').forEach(row => {
    if (!row.classList.contains('hidden')) {
      const input = row.querySelector('input[type="text"]');
      if (input && input.value.trim().length > 0) {
        hasInput = true;
      }
    }
  });
  searchBtn.disabled = !hasInput;
}

function loadMockData() {
  // Generate 50 rows of mock search results for testing
  stationArr = Array.from({ length: 50 }, (_, i) => {
    const wordCount = Math.floor(Math.random() * (60 - 3 + 1)) + 6; // Random word count between 6 and 200
    const name = Array.from({ length: wordCount }, () => `word${Math.floor(Math.random() * 1000)}`).join(' ');
    return {
      name,
      countrycode: ['US', 'CA', 'UK', 'DE', 'FR'][i % 5],
      codec: ['MP3', 'AAC', 'OGG', 'FLAC'][i % 4],
      bitrate: 64 + (i % 9) * 32,
      url_resolved: `http://example.com/stream${i + 1}`
    };
  });
  populateTable(stationArr);
  updatePageDisplay();
}

function setButtonsDisabled(disabled) {
  document.getElementById('prevPageBtn').disabled = disabled;
  document.getElementById('nextPageBtn').disabled = disabled;
  document.getElementById('addSearchRowBtn').disabled = disabled;
  document.querySelectorAll('.removeSearchRowBtn').forEach(btn => btn.disabled = disabled);
  // Also disable buttons in the tables
  document.querySelectorAll('.quickbuttontable button').forEach(btn => btn.disabled = disabled);
  document.querySelectorAll('#stationsTable button').forEach(btn => btn.disabled = disabled);

  // When re-enabling buttons, also update the state of the main search button
  if (!disabled) {
    updateSearchButtonState();
  }
}

function addSearchRow() {
  const row2 = document.getElementById('searchRow2');
  const row3 = document.getElementById('searchRow3');
  if (row2.classList.contains('hidden')) {
    row2.classList.remove('hidden');
  } else if (row3.classList.contains('hidden')) {
    row3.classList.remove('hidden');
  }
  // After potentially showing a row, check if all are visible to disable the add button
  if (!row2.classList.contains('hidden') && !row3.classList.contains('hidden')) {
    document.getElementById('addSearchRowBtn').disabled = true;
  }
}

function removeSearchRow(rowNum) {
  const row = document.getElementById(`searchRow${rowNum}`);
  if (row) {
    row.classList.add('hidden');
    document.getElementById(`searchInput${rowNum}`).value = '';
    // Always enable the add button when a row is removed
    document.getElementById('addSearchRowBtn').disabled = false;
  }
}

function initWebSocket() {
  if (testingMode) return; // Skip WebSocket initialization in testing mode

  console.log('Trying to open a WebSocket connection...');
  websocket = new WebSocket(gateway);
  websocket.onopen    = onOpen;
  websocket.onclose   = onClose;
  websocket.onmessage = onMessage;
}

function onOpen(event) {
  console.log('Connection opened');
}

function onClose(event) {
  console.log('Connection closed');
  setTimeout(initWebSocket, 2000);
}

function onMessage(event) {
  try {
    const data = JSON.parse(event.data);
    if(data.search_done){
      console.log("Search is done. Fetching results");
      // The search is done, so we expect searchresults.json to exist.
      fetchResults(true); // Show "loading" message
    } else if (data.search_failed) {
      console.error("Search failed on the backend. No servers available.");
      document.getElementById('stationsTable').innerHTML = '<tr><td class="importantmessage" colspan="4">Search failed. No servers available. Try again later.</td></tr>';
      hidePageNav();
      setButtonsDisabled(false); // Re-enable buttons on failure
    }
  } catch (e) {
    console.error("Error parsing websocket message", e);
    setButtonsDisabled(false); // Re-enable buttons on error
  }
}

function loadLastSearchAndResults() {
  let hasSearchHistory = false; // Flag to track if we should fetch results

  fetch('search.txt?t=' + Date.now())
  .then(response => {
    if (!response.ok) {
      if (response.status === 404) {
        // search.txt not found, which is normal on first run.
        // Don't try to fetch results.
        return null;
      }
      throw new Error('Failed to load search history');
    }
    return response.text();
  })
  .then(text => {
    // Always reset UI to a default state before applying history or on first load
    document.getElementById('searchInput1').value = '';
    document.getElementById('searchRow1').classList.remove('hidden'); // Ensure row 1 is always visible
    for (let i = 2; i <= 3; i++) {
      const row = document.getElementById(`searchRow${i}`);
      if(row) {
        row.classList.add('hidden');
        document.getElementById(`searchInput${i}`).value = '';
      }
    }
    document.getElementById('addSearchRowBtn').disabled = false;

    if (text === null) {
      // This was a 404, first run. Stop here.
      return; // hasSearchHistory remains false
    }

    const query = text.split('\n')[0].trim();
    if (!query) {
      // search.txt exists but is empty. No previous search to load.
      return; // hasSearchHistory remains false
    }

    // If we have history, parse and apply it
    hasSearchHistory = true; // We have a valid history to load
    let params = new URLSearchParams(query);
    let page = 0;
    if (params.has('offset')) {
      const offset = parseInt(params.get('offset'), 10) || 0;
      page = Math.floor(offset / limit_per_page); // Correctly calculate page from offset
    }
    currentPage = page;

    // Fill up to 3 search fields from the query history
    let rowNum = 1;
    for (const [key, value] of params.entries()) {
      if (["hidebroken","offset","limit","order","reverse"].includes(key)) continue;
      if (rowNum > 3) break;
      document.getElementById(`searchType${rowNum}`).value = key;
      document.getElementById(`searchInput${rowNum}`).value = value;
      if (rowNum > 1) {
        document.getElementById(`searchRow${rowNum}`).classList.remove('hidden');
      }
      rowNum++;
    }

    // Disable the 'add' button if all 3 rows are in use
    document.getElementById('addSearchRowBtn').disabled = (rowNum > 3);
    updatePageDisplay();
  })
  .catch(error => {
    console.log('Could not load last search:', error);
    // On error, don't try to fetch results, just show a clean slate.
    hasSearchHistory = false;
  })
  .finally(() => {
    // This block runs after the fetch promise chain is complete (either then or catch).
    if (hasSearchHistory) {
      fetchResults(false); // Fetch results based on history, don't show "loading" message
    } else {
      // No history or an error occurred, so just set the UI to its initial state.
      document.getElementById('stationsTable').innerHTML = '<tr><td class="importantmessage" colspan="4">Try searching.</td></tr>';
      hidePageNav();
      setButtonsDisabled(false);
    }
  });
}

function fetchResults(showLoadingMsg, retries = 5, delay = 300) {
  if (showLoadingMsg) {
    document.getElementById('stationsTable').innerHTML = '<tr><td class="importantmessage" colspan="4">Search completed. Loading results.</td></tr>';
    hidePageNav();
  }

  fetch('searchresults.json?t=' + Date.now())
  .then(response => {
    if (!response.ok) {
      if (response.status === 404 && retries > 0) {
        throw new Error('404_RETRY'); // Special error to trigger a retry
      }
      throw new Error(`Failed to fetch search results: ${response.statusText}`);
    }
    return response.json();
  })
  .then(data => {
    stationArr = Array.isArray(data) ? data : [];
    populateTable(stationArr);
    updatePageDisplay();
    setButtonsDisabled(false);
  })
  .catch(error => {
    if (error.message === '404_RETRY') {
      console.log(`File not found, retrying... (${retries} retries left)`);
      setTimeout(() => fetchResults(showLoadingMsg, retries - 1, delay), delay);
    } else {
      console.error('Error fetching search results:', error);
      document.getElementById('stationsTable').innerHTML = '<tr><td class="importantmessage" colspan="4">Failed to load results. Try refreshing this page or performing a new search.</td></tr>';
      stationArr = [];
      hidePageNav();
      setButtonsDisabled(false);
    }
  });
}

function hidePageNav() {
  const prevBtn = document.getElementById('prevPageBtn');
  const nextBtn = document.getElementById('nextPageBtn');
  const pageNav = document.getElementById('pageDisplay');
  prevBtn.classList.add('hidden');
  nextBtn.classList.add('hidden');
  pageNav.classList.add('hidden');
}

function updatePageDisplay() {
  const pageDisplay = document.getElementById('pageDisplay');
  const prevBtn = document.getElementById('prevPageBtn');
  const nextBtn = document.getElementById('nextPageBtn');

  // First, remove the hidden class from all elements so they can be controlled by visibility
  pageDisplay.classList.remove('hidden');
  prevBtn.classList.remove('hidden');
  nextBtn.classList.remove('hidden');

  pageDisplay.textContent = `Page ${currentPage + 1}`;

  // Use visibility to show/hide buttons. This keeps them in the layout and prevents alignment issues.
  prevBtn.style.visibility = currentPage <= 0 ? 'hidden' : 'visible';
  nextBtn.style.visibility = (!stationArr || stationArr.length < limit_per_page) ? 'hidden' : 'visible';
}

function changePage(delta) {
  const newPage = currentPage + delta;
  if (newPage < 0) return;
  currentPage = newPage;
  searchStations(true);
}

function searchStations(isPageNav = false) {
  if (!isPageNav) {
    currentPage = 0;
  }

  // Build a map of type -> value, only keeping the first occurrence of each type
  const typeValueMap = {};
  let searchTermFound = false;
  document.querySelectorAll('.search-row').forEach((row, index) => {
    if (!row.classList.contains('hidden')) {
      const i = row.id.replace('searchRow', ''); // Get index from ID
      const type = document.getElementById(`searchType${i}`).value;
      const searchValue = document.getElementById(`searchInput${i}`).value.trim();
      if (searchValue.length > 0 && !(type in typeValueMap)) {
        typeValueMap[type] = searchValue;
        searchTermFound = true;
      } else if (searchValue.length > 0 && type in typeValueMap) {
        // Duplicate type: clear and hide this row
        document.getElementById(`searchInput${i}`).value = '';
        row.classList.add('hidden');
        document.getElementById('addSearchRowBtn').disabled = false;
      }
    }
  });

  if (!searchTermFound) return;

  // Build the full query string for the API using URLSearchParams for robustness
  const params = new URLSearchParams({
    hidebroken: 'true',
    limit: limit_per_page,
    offset: currentPage * limit_per_page,
    order: 'name',
    reverse: 'false'
  });

  for (const [type, value] of Object.entries(typeValueMap)) {
    params.append(type, value);
  }
  const fullQueryString = params.toString();

  // Send the search request
  const url = `/search?search=${encodeURIComponent(fullQueryString)}`;

  document.getElementById('stationsTable').innerHTML = '<tr><td class="importantmessage" colspan="4">Waiting for results. Be patient.</td></tr>';
  hidePageNav();
  setButtonsDisabled(true); // Disable buttons when search starts

  fetch(url)
  .then(response => {
    if (!response.ok) {
      throw new Error(`Search request failed: ${response.statusText}`);
    }
    return response.json();
  })
  .then(data => {
    console.log('Request for search accepted. Waiting for results.', data);
  })
  .catch(error => {
    console.error('Error initiating search:', error);
    document.getElementById('stationsTable').innerHTML = '<tr><td class="importantmessage" colspan="4">Search failed. Try again?</td></tr>';
    hidePageNav();
    setButtonsDisabled(false); // Re-enable buttons on fetch error
  });
}

function populateTable(data) {
  const table = document.getElementById('stationsTable');
  table.innerHTML = "";
  if (!data || data.length === 0) {
    table.innerHTML = '<tr><td class="importantmessage" colspan="4">Try searching.</td></tr>';
    hidePageNav();
    return;
  }
  const rows = data.map((station, i) => {
    if (!station.url_resolved || !(station.url_resolved.startsWith("http:") || station.url_resolved.startsWith("https:"))) {
      return '';
    }
    return `
      <tr class="line">
        <td class="preview"><button class="button preview" data-action="preview" data-index="${i}"></button></td>
        <td class="name">${station.name}</td>
        <td class="info">
          <table>
            <tr>
              <td class="countrycode" colspan="2">${station.countrycode}</td>
            </tr>
            <tr>
              <td class="codec">${station.codec}</td>
              <td class="bitrate">${station.bitrate}k</td>
            </tr>
          </table>
        </td>
        <td class="add"><button class="button addtoplaylist" data-action="add" data-index="${i}"></button></td>
      </tr>
    `;
  }).join('');
  table.innerHTML = rows;
}

function quickSearch(genre) {
  document.getElementById('searchType1').value = 'tag';
  document.getElementById('searchInput1').value = genre;
  // Hide other search rows and clear their inputs
  for (let i = 2; i <= 3; i++) {
    const row = document.getElementById(`searchRow${i}`);
    if(row) {
      row.classList.add('hidden');
      document.getElementById(`searchInput${i}`).value = '';
    }
  }
  document.getElementById('addSearchRowBtn').disabled = false;

  searchStations();
}

function sendStationAction(inx, addtoplaylist) {
  const station = stationArr[inx];
  if (!station) {
    console.error('Invalid station index:', inx);
    return;
  }
  const name = station.name;
  const url = station.url_resolved || station.url;
  const label = addtoplaylist ? "Added to playlist: " : "Preview: ";
  const formData = new URLSearchParams();
  formData.append('name', name);
  formData.append('url', url);
  formData.append('addtoplaylist', addtoplaylist);
  fetch('/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: formData
  })
  .then(response => {
    if (!response.ok) throw new Error('Action failed');
    return response.text();
  })
  .then(responseText => {
    console.log(label + name, 'Response:', responseText);
  })
  .catch(error => console.error('Error sending station action:', error));
}